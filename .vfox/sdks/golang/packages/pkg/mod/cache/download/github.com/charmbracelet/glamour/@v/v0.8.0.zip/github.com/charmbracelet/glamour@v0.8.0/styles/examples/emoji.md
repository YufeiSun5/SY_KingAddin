:octopus: :zap: :cat: = :heart:
