---
sidebar_position: 1
---

# About

## Overview

Wails is a project that enables you to write desktop apps using Go and web technologies.

Consider it a lightweight and fast Electron alternative for Go. You can easily build applications with the flexibility
and power of Go, combined with a rich, modern frontend.

Wails doesn't hold back with the eye candy either! This is [xbar](https://xbarapp.com) - a desktop application for MacOS
written using Wails. It has menus, supports light and dark desktop themes, and the main window uses translucency that
gives it that 'frosty' effect of a native app.

<p class="text--center">
<a href="https://xbarapp.com"><img src="/img/xbar-app-preview-2.png" width="75%"/></a>
</p>

## Native Elements

Wails uses a purpose built library for handling native elements such as Window, Menus, Dialogs, etc, so you can build
good-looking, feature rich desktop applications.

**It does not embed a browser**, so it is resource efficient. Instead, it uses the native rendering engine for the
platform. On Windows, this is the new Microsoft Webview2 library, built on Chromium.

## Go & Javascript Interoperability

Wails automatically makes your Go methods available to Javascript, so you can call them by name from your frontend!
It even generates Typescript versions of the structs used by your Go methods, so you can pass the same data structures
between Go and Javascript.

## Runtime Library

Wails provides a runtime library, for both Go and Javascript, that handles a lot of the things modern applications need,
like Eventing, Logging, Dialogs, etc.

## Live Development Experience

### Automatic Rebuilds

When you run your application in "dev" mode, Wails will build your application as a native desktop application, but will
read your assets from disk. It will detect any changes to your Go code and automatically rebuild and relaunch your
application.

### Automatic Reloads

When changes to your application assets are detected, your running application will "reload", reflecting your changes
almost immediately.

### Develop your application in a Browser

If you prefer to debug and develop in a browser then Wails has you covered. The running application also has a webserver
that will run your application in any browser that connects to it. It will even refresh when your assets change on disk.

## Production-ready Native Binaries

When you're ready to do the final build of your application, the CLI will compile it down to a single executable, with
all the assets bundled into it. On Windows and MacOS, it is possible to create a native package for distribution. The
assets used in packaging (icon, info.plist, manifest file, etc) are part of your project and may be customised, giving
you total control over how your applications are built.

## Tooling

The Wails CLI provides a hassle-free way to generate, build and bundle your applications. It will do the heavy lifting
of creating icons, compiling your application with optimal settings and delivering a distributable, production ready
binary. Choose from a number of starter templates to get up and running quickly!
